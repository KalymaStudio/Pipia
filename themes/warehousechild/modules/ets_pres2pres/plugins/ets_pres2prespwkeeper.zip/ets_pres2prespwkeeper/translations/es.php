<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ets_pres2prespwkeeper}prestashop>ets_pres2prespwkeeper_bd8b2bd2ae1bd102d9174fd0d753d8ca'] = 'Prestashop Password Keeper';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>ets_pres2prespwkeeper_e6d2a849d92cefd044479fbb80d067bb'] = 'Mantenga las contraseñas antiguas cuando migre datos entre los sitios web de Prestashop utilizando Prestashop Migrator';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>ets_pres2prespwkeeper_923cc3fd014742fbc2a3dd76f2a7d8ca'] = 'Se requiere _COOKIE_KEY_ del sitio fuente';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>ets_pres2prespwkeeper_c888438d14855d7d96a2724ee9c306bd'] = 'Configuraciones se han actualizado';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>ets_pres2prespwkeeper_51ac4bf63a0c6a9cefa7ba69b4154ef1'] = 'Ajuste';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>ets_pres2prespwkeeper_97e6c933fc6cd2aa1da4a437bb9ea3f7'] = '_COOKIE_KEY_ del sitio web de origen';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>ets_pres2prespwkeeper_9c993291a1036a5ee376e8813d58c8e9'] = 'Se proporciona _COOKIE_KEY_ cuando finaliza la migración usando Prestashop Migrator. También está disponible en el archivo de configuración (settings.inc.php) del sitio web de origen.';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>ets_pres2prespwkeeper_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>form_fa535ffb25e1fd20341652f9be21e06e'] = 'Configurar';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>form_f25b7a4db1d87afa1d07b8c2355acef1'] = '_COOKIE_KEY_ del sitio web de origen';
$_MODULE['<{ets_pres2prespwkeeper}prestashop>form_b17f3f4dcf653a5776792498a9b44d6a'] = 'Ajustes de actualización';
