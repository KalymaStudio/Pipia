<?php
/**
 * 2007-2018 ETS-Soft
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 wesite only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please contact us for extra customization service at an affordable price
 *
 * @author ETS-Soft <etssoft.jsc@gmail.com>
 * @copyright  2007-2018 ETS-Soft
 * @license    Valid for 1 website (or project) for each purchase of license
 *  International Registered Trademark & Property of ETS-Soft
 */

if (!defined('_PS_ADMIN_DIR_')) {
    define('_PS_ADMIN_DIR_', getcwd());
}
if (!defined('PS_INSTALLATION_IN_PROGRESS')) {
    define('PS_INSTALLATION_IN_PROGRESS', 1);
}
include(_PS_ADMIN_DIR_ . '/../../config/config.inc.php');
include(dirname(__FILE__) . '/ajax.init.php');
@ini_set('display_errors', 'off');
$context = Context::getContext();
if ($context->employee->id && Tools::getValue('token') == Tools::getAdminTokenLite('AdminModules')) {
    include(dirname(__FILE__) . '/importer.php');
} else {
    $ets_datamaster = Module::getInstanceByName('ets_oneclicktomigrate');
    $errors = array();
    $errors[] = $ets_datamaster->l('You have been logged out. Please login then resume the import');
    die(Tools::jsonEncode(array(
        'error' => true,
        'errors' => $ets_datamaster->displayError($errors),
    )));
}